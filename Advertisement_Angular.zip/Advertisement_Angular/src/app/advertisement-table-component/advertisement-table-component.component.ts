import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-advertisement-table-component',
  templateUrl: './advertisement-table-component.component.html',
  styleUrls: ['./advertisement-table-component.component.css']
})
export class AdvertisementTableComponentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
